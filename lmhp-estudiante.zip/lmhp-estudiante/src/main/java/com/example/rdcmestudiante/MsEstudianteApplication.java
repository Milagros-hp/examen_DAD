package com.example.rdcmestudiante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsEstudianteApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsEstudianteApplication.class, args);
    }
}
