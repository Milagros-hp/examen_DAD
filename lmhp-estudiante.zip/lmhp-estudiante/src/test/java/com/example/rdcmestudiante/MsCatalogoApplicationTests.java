package com.example.rdcmestudiante;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCatalogoApplicationTests {

    @Test
    void contextLoads() {
    }

}
